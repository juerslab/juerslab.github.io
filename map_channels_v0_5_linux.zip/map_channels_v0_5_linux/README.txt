July 2014
Doug Juers
Whitman College
Walla Walla, WA 99362
juersdh@whitman.edu

This zip files contains two files (in addition to this README file).
1. map_channels - a linux executable (statically linked)
2. map_channels.coot.py.x.x - a python plugin for COOT


Installation & running map_channels

1. The executable is known to run on Ubuntu and CentOS. If it needs to be turned into an
executable: 'chmod +x map_channels'

2. Run from the command line: 'map_channels pdbfile'

3. To get help: 'map_channels' or 'map_channels -h'

-------------

Installation & running the coot plugin

1. Copy map_channels.coot.py.x.x to .coot.py in root directory (be sure to backup any coot.py that is already present).

2. Copy map_channels to somewhere in the path.

3. Run coot. It may be necessary to run coot from the command line, in order to have a terminal in which to see the output from map_channels.

4. There should be a menubar item titled "Solvent Channels". Map_channels can be run from this menubar.
