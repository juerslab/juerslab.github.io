Feb 2015
Doug Juers
Whitman College
Walla Walla, WA 99362
juersdh@whitman.edu

This zip files contains two files (in addition to this README file).
1. map_channels - a Windows executable 
2. map_channels.wincoot.py.x.x - a python plugin for COOT


Installation & running map_channels

1. The executable should run on Windows 7. If it needs to be turned into an
executable: 'chmod +x map_channels'

2. Run from the command line: 'map_channels pdbfile'

3. To get help: 'map_channels' or 'map_channels -h'

-------------

Installation & running the coot plugin

1. Copy map_channels.wincoot.py.x.x to .coot.py in the main WinCoot directory (be sure to backup any coot.py that is already present).

2. Copy map_channels to Wincoot/bin

3. Run coot, there should be a menubar item titled "Solvent Channels". Map_channels can be run from this menubar.
